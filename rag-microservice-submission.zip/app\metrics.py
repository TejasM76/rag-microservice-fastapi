from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from prometheus_client import CollectorRegistry

# Create a custom registry
registry = CollectorRegistry()

# Define metrics
request_count = Counter(
    'rag_requests_total',
    'Total number of requests',
    ['endpoint', 'status'],
    registry=registry
)

request_latency = Histogram(
    'rag_request_latency_seconds',
    'Request latency in seconds',
    ['endpoint'],
    registry=registry
)

retrieval_hit_rate = Gauge(
    'rag_retrieval_hit_rate',
    'Retrieval hit rate at k',
    registry=registry
)

failure_count = Counter(
    'rag_failures_total',
    'Total number of failures',
    ['endpoint', 'error_type'],
    registry=registry
)

active_documents = Gauge(
    'rag_active_documents',
    'Number of active documents in vector store',
    registry=registry
)


def get_metrics():
    """Return Prometheus metrics in text format."""
    return generate_latest(registry)
