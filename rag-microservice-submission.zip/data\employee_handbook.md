# Employee Handbook

## Work Hours

Standard work hours are Monday through Friday, 9:00 AM to 5:00 PM.

## Benefits

Employees are eligible for:
- Health insurance after 90 days
- 15 days paid time off per year
- 401(k) matching up to 4%
- Professional development budget of $1,000 annually

## Code of Conduct

Employees are expected to:
- Treat colleagues with respect
- Maintain confidentiality of company information
- Follow all company policies and procedures
- Report any violations to HR

## Remote Work Policy

Employees may work remotely up to 2 days per week with manager approval.
Remote workers must maintain regular communication and meeting attendance.
