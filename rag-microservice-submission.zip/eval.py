import json
import time
import requests
from typing import List, Dict, Any
from pathlib import Path
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from rouge_score import rouge_scorer

# Configuration
API_URL = "http://localhost:8000"
EVAL_SET_PATH = "eval_set.jsonl"
RESULTS_PATH = "eval_results/eval_results.json"
SUMMARY_PATH = "eval_results/eval_summary.txt"


def load_eval_set(path: str) -> List[Dict[str, Any]]:
    """Load evaluation dataset."""
    eval_data = []
    with open(path, 'r') as f:
        for line in f:
            eval_data.append(json.loads(line))
    return eval_data


def evaluate_retrieval_recall(contexts: List[Dict], reference_filename: str, k: int) -> bool:
    """Check if any of the top-k contexts match the reference filename."""
    for ctx in contexts[:k]:
        if ctx['filename'] == reference_filename:
            return True
    return False


def compute_answer_similarity(answer: str, reference: str, embedder: SentenceTransformer) -> float:
    """Compute cosine similarity between answer and reference."""
    if not answer or not reference:
        return 0.0

    answer_emb = embedder.encode([answer])
    ref_emb = embedder.encode([reference])
    similarity = cosine_similarity(answer_emb, ref_emb)[0][0]
    return float(similarity)


def compute_rouge_l(answer: str, reference: str) -> float:
    """Compute ROUGE-L score."""
    scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    scores = scorer.score(reference, answer)
    return scores['rougeL'].fmeasure


def run_evaluation():
    """Run evaluation on the eval set."""
    print("Loading evaluation set...")
    eval_data = load_eval_set(EVAL_SET_PATH)

    print("Loading embedding model for similarity computation...")
    embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    results = []
    recall_scores = []
    similarity_scores = []
    rouge_scores = []
    latencies = []

    print(f"\nEvaluating {len(eval_data)} questions...\n")

    for item in eval_data:
        question_id = item['id']
        question = item['question']
        reference_answer = item['answer_ref']
        reference_filename = item.get('filename', '')

        print(f"Evaluating {question_id}: {question[:60]}...")

        try:
            # Call the API
            start_time = time.time()
            response = requests.post(
                f"{API_URL}/ask",
                json={"query": question, "k": 5},
                timeout=30
            )
            latency = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()
                answer = data['answer']
                contexts = data['contexts']
                confidence = data['confidence']

                # Compute metrics
                recall = evaluate_retrieval_recall(contexts, reference_filename, k=5)
                similarity = compute_answer_similarity(answer, reference_answer, embedder)
                rouge_l = compute_rouge_l(answer, reference_answer)

                recall_scores.append(1 if recall else 0)
                similarity_scores.append(similarity)
                rouge_scores.append(rouge_l)
                latencies.append(latency)

                results.append({
                    "id": question_id,
                    "question": question,
                    "reference_answer": reference_answer,
                    "generated_answer": answer,
                    "reference_filename": reference_filename,
                    "recall_at_5": recall,
                    "cosine_similarity": round(similarity, 3),
                    "rouge_l": round(rouge_l, 3),
                    "latency_ms": round(latency, 2),
                    "confidence": confidence,
                    "contexts_retrieved": len(contexts)
                })

                print(f"  ✓ Recall: {recall} | Similarity: {similarity:.3f} | ROUGE-L: {rouge_l:.3f} | Latency: {latency:.0f}ms")

            else:
                print(f"  ✗ API Error: {response.status_code}")
                results.append({
                    "id": question_id,
                    "question": question,
                    "error": f"HTTP {response.status_code}",
                    "recall_at_5": False,
                    "cosine_similarity": 0.0,
                    "rouge_l": 0.0,
                    "latency_ms": 0
                })

        except Exception as e:
            print(f"  ✗ Error: {str(e)}")
            results.append({
                "id": question_id,
                "question": question,
                "error": str(e),
                "recall_at_5": False,
                "cosine_similarity": 0.0,
                "rouge_l": 0.0,
                "latency_ms": 0
            })

    # Compute aggregate metrics
    avg_recall = sum(recall_scores) / len(recall_scores) if recall_scores else 0
    avg_similarity = sum(similarity_scores) / len(similarity_scores) if similarity_scores else 0
    avg_rouge = sum(rouge_scores) / len(rouge_scores) if rouge_scores else 0
    avg_latency = sum(latencies) / len(latencies) if latencies else 0

    summary_line = (
        f"n={len(eval_data)} | "
        f"Recall@5={avg_recall:.2f} | "
        f"AvgCosineSim={avg_similarity:.2f} | "
        f"AvgROUGE-L={avg_rouge:.2f} | "
        f"AvgLatency={avg_latency:.0f}ms"
    )

    print("\n" + "="*70)
    print("EVALUATION SUMMARY")
    print("="*70)
    print(summary_line)
    print("="*70 + "\n")

    # Save results
    Path("eval_results").mkdir(exist_ok=True)

    with open(RESULTS_PATH, 'w') as f:
        json.dump({
            "summary": {
                "total_questions": len(eval_data),
                "avg_recall_at_5": round(avg_recall, 3),
                "avg_cosine_similarity": round(avg_similarity, 3),
                "avg_rouge_l": round(avg_rouge, 3),
                "avg_latency_ms": round(avg_latency, 2)
            },
            "results": results
        }, f, indent=2)

    with open(SUMMARY_PATH, 'w') as f:
        f.write(summary_line + "\n")

    print(f"Results saved to {RESULTS_PATH}")
    print(f"Summary saved to {SUMMARY_PATH}")


if __name__ == "__main__":
    run_evaluation()
