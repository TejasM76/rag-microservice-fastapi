from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    embed_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    top_k: int = 5
    confidence_threshold: float = 0.5
    chunk_size: int = 500
    chunk_overlap: int = 50
    version: str = "1.0.0"
    build_sha: str = "dev"
    log_level: str = "INFO"
    data_directory: str = "./data"
    persist_directory: str = "./faiss_db"

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
