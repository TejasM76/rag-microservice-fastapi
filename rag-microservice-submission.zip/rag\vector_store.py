from typing import List, Dict, Any, Optional
import faiss
import numpy as np
import pickle
from pathlib import Path
import structlog

logger = structlog.get_logger()


class VectorStore:
    def __init__(self, persist_directory: str = "./faiss_db"):
        self.persist_directory = Path(persist_directory)
        self.persist_directory.mkdir(exist_ok=True)
        self.index_path = self.persist_directory / "index.faiss"
        self.metadata_path = self.persist_directory / "metadata.pkl"
        self.index = None
        self.metadata = []
        self.dimension = None

    def initialize(self):
        """Initialize or load the index."""
        if self.index_path.exists() and self.metadata_path.exists():
            try:
                self.index = faiss.read_index(str(self.index_path))
                with open(self.metadata_path, 'rb') as f:
                    self.metadata = pickle.load(f)
                self.dimension = self.index.d
                logger.info("index_loaded", path=str(self.index_path), count=len(self.metadata))
            except Exception as e:
                logger.warning("index_load_failed", error=str(e))
                self.index = None
                self.metadata = []
        else:
            logger.info("new_index_will_be_created")

    def add_documents(self, chunks: List[Dict[str, Any]], embeddings: List[List[float]]):
        """Add document chunks with embeddings to the vector store."""
        if not chunks or not embeddings:
            logger.warning("no_documents_to_add")
            return
        
        embeddings_array = np.array(embeddings, dtype='float32')
        
        # Normalize embeddings for better similarity search
        faiss.normalize_L2(embeddings_array)
        
        if self.index is None:
            self.dimension = embeddings_array.shape[1]
            # Use IndexFlatIP for inner product (cosine similarity after normalization)
            self.index = faiss.IndexFlatIP(self.dimension)
            logger.info("index_created", dimension=self.dimension)
        
        self.index.add(embeddings_array)
        self.metadata.extend(chunks)
        
        # Save to disk
        self._persist()
        
        logger.info("documents_added", count=len(chunks), total=len(self.metadata))

    def search(
        self,
        query_embedding: List[float],
        k: int = 5,
        filename_filter: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Search for similar documents."""
        if self.index is None or len(self.metadata) == 0:
            logger.warning("empty_index_search_attempted")
            return []
        
        # Normalize query embedding
        query_array = np.array([query_embedding], dtype='float32')
        faiss.normalize_L2(query_array)
        
        # Search more results if filtering is needed
        search_k = min(k * 3 if filename_filter else k, len(self.metadata))
        
        try:
            distances, indices = self.index.search(query_array, search_k)
        except Exception as e:
            logger.error("search_failed", error=str(e))
            return []
        
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx >= 0 and idx < len(self.metadata):
                metadata = self.metadata[idx]
                
                # Apply filename filter
                if filename_filter and metadata['filename'] not in filename_filter:
                    continue
                
                # Convert distance to similarity score (0-1 range)
                # For IndexFlatIP, distance is already cosine similarity
                similarity_score = float(dist)
                
                results.append({
                    'text': metadata['text'],
                    'filename': metadata['filename'],
                    'page': metadata['page'],
                    'chunk_id': metadata['chunk_id'],
                    'score': similarity_score
                })
                
                if len(results) >= k:
                    break
        
        return results

    def count(self) -> int:
        """Get the number of documents in the collection."""
        return len(self.metadata) if self.metadata else 0

    def reset(self):
        """Clear all documents from the collection."""
        self.index = None
        self.metadata = []
        self.dimension = None
        
        if self.index_path.exists():
            self.index_path.unlink()
        if self.metadata_path.exists():
            self.metadata_path.unlink()
        
        logger.info("index_reset")

    def _persist(self):
        """Save index and metadata to disk."""
        try:
            faiss.write_index(self.index, str(self.index_path))
            with open(self.metadata_path, 'wb') as f:
                pickle.dump(self.metadata, f)
        except Exception as e:
            logger.error("persist_failed", error=str(e))
