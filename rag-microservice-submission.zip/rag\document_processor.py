import os
import re
from typing import List, Dict, Any
from pathlib import Path
import fitz  # PyMuPDF
import structlog

logger = structlog.get_logger()


class DocumentProcessor:
    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 50):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def load_document(self, file_path: str) -> List[Dict[str, Any]]:
        """Load document from PDF or Markdown file."""
        path = Path(file_path)
        if not path.exists():
            logger.error("file_not_found", path=file_path)
            raise FileNotFoundError(f"File not found: {file_path}")

        if path.suffix.lower() == '.pdf':
            return self._load_pdf(file_path)
        elif path.suffix.lower() in ['.md', '.markdown', '.txt']:
            return self._load_text(file_path)
        else:
            raise ValueError(f"Unsupported file type: {path.suffix}")

    def _load_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        """Load and process PDF file."""
        documents = []
        filename = Path(file_path).name

        try:
            doc = fitz.open(file_path)
            for page_num, page in enumerate(doc, start=1):
                text = page.get_text()
                cleaned_text = self._clean_text(text)

                if cleaned_text.strip():
                    documents.append({
                        'text': cleaned_text,
                        'filename': filename,
                        'page': page_num,
                        'source': file_path
                    })

            doc.close()
            logger.info("pdf_loaded", filename=filename, pages=len(documents))

        except Exception as e:
            logger.error("pdf_load_error", filename=filename, error=str(e))
            raise

        return documents

    def _load_text(self, file_path: str) -> List[Dict[str, Any]]:
        """Load and process text/markdown file."""
        filename = Path(file_path).name

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()

            cleaned_text = self._clean_text(text)

            return [{
                'text': cleaned_text,
                'filename': filename,
                'page': 1,
                'source': file_path
            }]

        except Exception as e:
            logger.error("text_load_error", filename=filename, error=str(e))
            raise

    def _clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s.,!?;:()\-\']', '', text)
        return text.strip()

    def chunk_documents(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Split documents into chunks with metadata."""
        chunks = []
        chunk_id = 0

        for doc in documents:
            text = doc['text']
            words = text.split()

            for i in range(0, len(words), self.chunk_size - self.chunk_overlap):
                chunk_text = ' '.join(words[i:i + self.chunk_size])

                if len(chunk_text.strip()) > 50:  # Minimum chunk size
                    chunks.append({
                        'text': chunk_text,
                        'filename': doc['filename'],
                        'page': doc['page'],
                        'chunk_id': chunk_id,
                        'source': doc['source']
                    })
                    chunk_id += 1

        logger.info("documents_chunked", total_chunks=len(chunks))
        return chunks
