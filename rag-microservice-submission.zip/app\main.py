import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional
from pathlib import Path

import structlog
from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import PlainTextResponse

from .config import settings
from .models import (
    IngestRequest, IngestResponse,
    QueryRequest, QueryResponse,
    HealthResponse
)
from .metrics import (
    request_count, request_latency, failure_count,
    active_documents, get_metrics, CONTENT_TYPE_LATEST
)
from rag.rag_pipeline import RAGPipeline

# Configure structured logging
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.add_log_level,
        structlog.processors.JSONRenderer()
    ]
)

logger = structlog.get_logger()

# Global RAG pipeline instance
rag_pipeline: Optional[RAGPipeline] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    global rag_pipeline

    # Startup
    logger.info("application_starting", version=settings.version)
    rag_pipeline = RAGPipeline(
        embed_model=settings.embed_model,
        chunk_size=settings.chunk_size,
        chunk_overlap=settings.chunk_overlap,
        persist_directory=settings.persist_directory
    )
    logger.info("rag_pipeline_initialized")

    yield

    # Shutdown
    logger.info("application_shutting_down")


app = FastAPI(
    title="RAG Microservice",
    version=settings.version,
    lifespan=lifespan
)


@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint."""
    return HealthResponse(
        status="ok",
        version=settings.version,
        build_sha=settings.build_sha
    )


@app.post("/ingest", response_model=IngestResponse)
async def ingest(request: IngestRequest):
    """Ingest documents into the RAG system."""
    request_id = str(uuid.uuid4())
    start_time = time.time()

    logger.info("ingest_request_received", request_id=request_id)

    try:
        # Determine document paths
        if request.documents:
            document_paths = [doc.path for doc in request.documents]
        else:
            # Default to scanning data directory
            data_dir = Path(settings.data_directory)
            if not data_dir.exists():
                raise HTTPException(status_code=400, detail="Data directory not found")

            document_paths = []
            for ext in ['.pdf', '.md', '.markdown', '.txt']:
                document_paths.extend(str(p) for p in data_dir.glob(f'*{ext}'))

        if not document_paths:
            raise HTTPException(status_code=400, detail="No documents to ingest")

        # Ingest documents
        result = rag_pipeline.ingest_documents(document_paths)

        # Update metrics
        active_documents.set(rag_pipeline.vector_store.count())
        request_count.labels(endpoint='ingest', status='success').inc()

        latency = time.time() - start_time
        request_latency.labels(endpoint='ingest').observe(latency)

        logger.info(
            "ingest_completed",
            request_id=request_id,
            ingested=result['ingested'],
            chunks=result['chunks'],
            latency_ms=round(latency * 1000, 2)
        )

        return IngestResponse(**result)

    except HTTPException:
        raise
    except Exception as e:
        failure_count.labels(endpoint='ingest', error_type=type(e).__name__).inc()
        request_count.labels(endpoint='ingest', status='error').inc()
        logger.error("ingest_error", request_id=request_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask", response_model=QueryResponse)
async def ask(request: QueryRequest):
    """Answer questions using RAG."""
    request_id = str(uuid.uuid4())
    start_time = time.time()

    logger.info(
        "query_request_received",
        request_id=request_id,
        query=request.query[:100]  # Truncate for logging
    )

    try:
        # Extract filename filter if provided
        filename_filter = None
        if request.filters and 'filename' in request.filters:
            filename_filter = request.filters['filename']

        # Query the RAG system
        result = rag_pipeline.query(
            question=request.query,
            k=request.k,
            filename_filter=filename_filter,
            confidence_threshold=settings.confidence_threshold
        )

        latency = time.time() - start_time
        result['latency_ms'] = round(latency * 1000, 2)

        # Update metrics
        request_count.labels(endpoint='ask', status='success').inc()
        request_latency.labels(endpoint='ask').observe(latency)

        logger.info(
            "query_completed",
            request_id=request_id,
            confidence=result['confidence'],
            review_required=result['review_required'],
            latency_ms=result['latency_ms']
        )

        return QueryResponse(**result)

    except Exception as e:
        failure_count.labels(endpoint='ask', error_type=type(e).__name__).inc()
        request_count.labels(endpoint='ask', status='error').inc()
        logger.error("query_error", request_id=request_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return Response(content=get_metrics(), media_type=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
