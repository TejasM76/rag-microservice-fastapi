# RAG Microservice Submission

## Evaluation Results
n=15 | Recall@5=1.00 | AvgCosineSim=0.38 | AvgROUGE-L=0.10 | AvgLatency=2086ms

## Tradeoffs
- Used FAISS instead of Chroma (Windows compatibility)
- Simple extractive answers (no LLM generation)
- Fixed-size chunking (500 words with 50 overlap)

## Running Instructions
1. Install: pip install -r requirements.txt
2. Start: python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
3. Ingest: curl -X POST http://localhost:8000/ingest -d '{}'
4. Evaluate: python eval.py