from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class DocumentInput(BaseModel):
    path: str


class IngestRequest(BaseModel):
    documents: Optional[List[DocumentInput]] = None


class IngestResponse(BaseModel):
    ingested: int
    chunks: int


class QueryRequest(BaseModel):
    query: str
    k: int = Field(default=5, ge=1, le=20)
    filters: Optional[Dict[str, List[str]]] = None


class Context(BaseModel):
    text: str
    filename: str
    page: int
    score: float


class QueryResponse(BaseModel):
    answer: str
    contexts: List[Context]
    latency_ms: float
    confidence: float
    review_required: bool
    explanation: Optional[str] = None
    escalation_note: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    build_sha: str
