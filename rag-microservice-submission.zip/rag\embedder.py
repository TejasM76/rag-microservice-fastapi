from typing import List
from sentence_transformers import SentenceTransformer
import structlog

logger = structlog.get_logger()


class Embedder:
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        self.model_name = model_name
        logger.info("loading_embedding_model", model=model_name)
        self.model = SentenceTransformer(model_name)
        logger.info("embedding_model_loaded", model=model_name)

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts."""
        embeddings = self.model.encode(texts, show_progress_bar=False)
        return embeddings.tolist()

    def embed_text(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        embedding = self.model.encode([text], show_progress_bar=False)
        return embedding[0].tolist()
