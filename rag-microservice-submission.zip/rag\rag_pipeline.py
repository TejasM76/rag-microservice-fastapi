from typing import List, Dict, Any, Optional
import structlog
from .document_processor import DocumentProcessor
from .embedder import Embedder
from .vector_store import VectorStore

logger = structlog.get_logger()


class RAGPipeline:
    def __init__(
        self,
        embed_model: str,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        persist_directory: str = "./faiss_db"
    ):
        self.processor = DocumentProcessor(chunk_size, chunk_overlap)
        self.embedder = Embedder(embed_model)
        self.vector_store = VectorStore(persist_directory)
        self.vector_store.initialize()

    def ingest_documents(self, document_paths: List[str]) -> Dict[str, int]:
        """Ingest documents into the RAG system."""
        all_chunks = []

        for path in document_paths:
            try:
                documents = self.processor.load_document(path)
                chunks = self.processor.chunk_documents(documents)
                all_chunks.extend(chunks)
                logger.info("document_processed", path=path, chunks=len(chunks))
            except Exception as e:
                logger.error("document_ingestion_error", path=path, error=str(e))
                continue

        if not all_chunks:
            logger.warning("no_chunks_generated")
            return {"ingested": 0, "chunks": 0}

        # Generate embeddings
        texts = [chunk['text'] for chunk in all_chunks]
        embeddings = self.embedder.embed_texts(texts)

        # Add to vector store
        self.vector_store.add_documents(all_chunks, embeddings)

        return {
            "ingested": len(document_paths),
            "chunks": len(all_chunks)
        }

    def query(
        self,
        question: str,
        k: int = 5,
        filename_filter: Optional[List[str]] = None,
        confidence_threshold: float = 0.5
    ) -> Dict[str, Any]:
        """Query the RAG system."""
        # Generate query embedding
        query_embedding = self.embedder.embed_text(question)

        # Search for relevant chunks
        results = self.vector_store.search(query_embedding, k, filename_filter)

        if not results:
            return {
                "answer": "I couldn't find relevant information to answer this question.",
                "contexts": [],
                "confidence": 0.0,
                "review_required": True,
                "explanation": "No relevant documents found",
                "escalation_note": "Query returned no results from vector store"
            }

        # Calculate confidence based on top result score
        # For FAISS IndexFlatIP, score is cosine similarity (0-1 range)
        top_score = results[0]['score']
        confidence = float(top_score)

        # Generate answer with citations
        answer = self._generate_answer(question, results)

        review_required = confidence < confidence_threshold
        explanation = ""
        escalation_note = ""

        if review_required:
            explanation = f"Low confidence score: {confidence:.2f} (threshold: {confidence_threshold})"
            escalation_note = f"Query '{question}' requires human review due to low confidence"

        return {
            "answer": answer,
            "contexts": results,
            "confidence": round(confidence, 3),
            "review_required": review_required,
            "explanation": explanation if review_required else None,
            "escalation_note": escalation_note if review_required else None
        }

    def _generate_answer(self, question: str, contexts: List[Dict[str, Any]]) -> str:
        """Generate an answer using retrieved contexts."""
        # Simple extractive answer with citations
        answer_parts = []
        seen_sources = set()

        for ctx in contexts[:3]:  # Use top 3 contexts
            source_key = f"{ctx['filename']}:p{ctx['page']}"
            if source_key not in seen_sources:
                # Extract relevant sentence or use first part of chunk
                text_preview = ctx['text'][:300].strip()
                if text_preview:
                    answer_parts.append(
                        f"{text_preview}... [Source: {ctx['filename']}, Page {ctx['page']}, "
                        f"Confidence: {ctx['score']:.2f}]"
                    )
                    seen_sources.add(source_key)

        if answer_parts:
            return " ".join(answer_parts)
        else:
            return "Based on the available documents, I found relevant information but cannot provide a specific answer."
