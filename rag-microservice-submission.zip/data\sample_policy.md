# Company Safety Policy

## Safety Requirements

All employees must follow these key safety requirements:

1. Wear appropriate personal protective equipment (PPE) at all times in designated areas
2. Report any safety hazards immediately to your supervisor
3. Complete mandatory safety training within 30 days of employment
4. Follow lockout/tagout procedures when working with machinery
5. Maintain clean and organized workspaces

## Emergency Procedures

In case of emergency:
- Evacuate using the nearest exit
- Report to the designated assembly point
- Do not re-enter the building until authorized
- Contact emergency services if needed

## Reporting Incidents

All incidents must be reported within 24 hours using the online incident reporting system.
